# AMULET KOREA — NEW EDITION

Шинээр бичсэн, GitHub + Vercel + Supabase системтэй холбох боломжтой онлайн шоп.

## 0. Чухал

- **ХУУЧИН САЙТ, SUPABASE ХҮСНЭГТҮҮДЭЭ ОДОО БҮҮ УСТГА.** Шинэ хувилбарыг шалгасны дараа соль.
- Энэ багц шинэ систем; хуучин `amulet-korea-shop` кодыг дарж солихгүйгээр шинэ `amulet-korea-premium` repository-д байршуул.
- Нүүр хуудсыг `index.html` файлаар компьютер дээр шууд нээж, **демо бараа** үзэж болно.
- **Демо горимд захиалга хадгалахгүй!** `config.js`, SQL, серверийн нууц түлхүүрийг тохируулбал бодит захиалга ажиллана.
- Барааны нэр, зураг, үнэ demo дотор жишээ. Бодит бараагаа админ хэсгээр нэмж оруулна.
- Барааны үнэ KRW. Монгол төгрөг, QPay, картын бодит төлбөрийн холболт хийгдээгүй. Хүргэлтийн төлбөр автоматаар тооцогдохгүй.

## 1. Файлын бүтэц

```
index.html           — онлайн дэлгүүр
admin.html           — админ
config.js            — нийтэд ил байж болох Supabase project URL + publishable/anon key
assets/style.css     — дэлгүүрийн загвар
assets/shop.js       — каталог, хайлт, сагс, захиалга
assets/admin.css     — админ загвар
assets/admin.js      — админ нэвтрэлт, бараа, захиалга
assets/favicon.svg  — лого дүрс
api/order.js         — сервер дээр үнэ / үлдэгдэл шалгаж захиалга хадгална
sql/setup.sql        — шинэ Supabase төслийн хүснэгт, RLS эрх
vercel.json          — Vercel тохиргоо
```

## 2. GitHub руу оруулах

1. Эхлээд хуучин repository-гээ нөөцөлж аваарай (`Code -> Download ZIP` эсвэл branch).
2. GitHub дахь `amulet-korea-premium` repository-гаа нээнэ.
3. Шинэ branch үүсгэнэ: `new-store-test`.
4. **Add file → Upload files** дээр энэ багцын **доторх** файлуудыг оруул. `api`, `assets`, `sql` хавтсуудын бүтцийг хадгал.
5. **Commit changes**. Нэгэн зэрэг хуучин production сайтаа бүү соль.
6. GitHub-ийн веб интерфейс дээр хавтас бүтнээр нь оруулахад хүндрэлтэй бол VS Code + GitHub Desktop ашиглах нь найдвартай.

## 3. Supabase — шинээр тохируулах

1. https://supabase.com/dashboard дээр **New project** үүсгэнэ.
2. SQL Editor → `sql/setup.sql` файлын агуулгыг хуулж **Run** дарна.
3. Authentication → Users → **Add user** → өөрийн админ email/password-аа үүсгэнэ. Нууц үгээ нийтэд битгий ил тавь.
4. Үүсгэсэн Auth хэрэглэгчийн UUID-г хуулна.
5. SQL Editor дээр: `insert into public.admin_users (user_id) values ('AUTH-USER-UUID');` гэж өөрийн UUID-гаар солиод Run дарна.
6. Project Settings → API Keys хэсгээс **Project URL**, **anon/publishable key** авч `config.js` дотор оруулна.
7. **SERVICE_ROLE/SECRET KEY** нь браузер, `config.js`, GitHub, админ HTML-д орох ЁСГҮЙ.
8. `/admin.html` руу орж имэйл/нууц үгээр нэвтэрч бараа нэмнэ. `products` хүснэгтэнд эхнээсээ жишээ бараа байхгүй; дэлгүүр эхлээд хоосон харагдана.

## 4. Vercel — шинэ URL гаргах

1. https://vercel.com/new дээр GitHub-ийн шинэ `amulet-korea-premium` repository-г холбоно.
2. Framework Preset = **Other**, Root Directory = `./`.
3. Vercel Project → Settings → Environment Variables хэсэгт нууц серверийн түлхүүрүүдийг оруулна:
   - `SUPABASE_URL` = өөрийн Supabase URL
   - `SUPABASE_SERVICE_ROLE_KEY` = Supabase service_role/secret key **(зөвхөн Vercel environment variables-д)**
4. Production болон Preview environment-д тохируулахдаа аль DB-г ашиглахыг анхаар. Шинэ store test нь шинэ Supabase project дээр байх нь аюулгүй.
5. Deploy / Redeploy. Анх `config.js` өөрчилсний дараа commit хийнэ.
6. Шинэ URL дээр бараа, сагс, захиалга, админ, утасны харагдацыг шалгана.

## 5. Туршилтын захиалга

1. Админ дээр 1 ширхэг бодит бус туршилтын бараа нэмэх (үнэ KRW, үлдэгдэл 5).
2. Дэлгүүрээс барааг сагсанд хийж захиалга илгээх.
3. Supabase `orders` хүснэгтэд захиалга нэмэгдсэн эсэхийг шалга.
4. Админ → Захиалга таб дээр харагдах эсэх, статус өөрчлөгдөх эсэхийг шалга.
5. Туршилтын өгөгдлөө production-д нийтлэхээс өмнө цэвэрлэ.

## 6. Хуучин сайтыг хэзээ солих вэ?

Шинэ линк дээр тест бүрэн болсны дараа л Vercel Project → Settings → Domains хэсэгт **өөрийн эзэмшдэг** домэйныг шинэ project рүү шилжүүлнэ. Хуучин project-ийг түр хадгалж үлдээнэ. `amulet-korea-shop.vercel.app` зэрэг Vercel-ийн үүсгэсэн subdomain-ыг өөр project-д шууд шилжүүлэх эсэх нь тухайн Vercel account/settings-ээс хамаарна.

## 7. Хараахан хийгдээгүй зүйлс

- Төлбөрийн gateway (QPay, Toss, KakaoPay, карт)
- Telegram/email захиалгын автомат мэдэгдэл
- Зураг upload storage (одоогоор HTTPS зургийн URL оруулна)
- Сток бууруулах transactional reservation; өндөр ачаалалтай үед race condition боломжтой
- Spam/rate-limit/CAPTCHA, privacy policy, shipping fee calculation, return policy
- Native Android/iOS апп болон app store publication

Том дэлгүүр болгон нийтлэхээс өмнө дээрх зүйлсийг нэмж, бодит тест хийх шаардлагатай.

## 8. Тайлбар

Admin нэвтрэлт Supabase Auth ашиглана, RLS нь зөвхөн admin users-д бараа засах болон захиалга унших эрх өгнө. `api/order.js` нь захиалгын нийт үнийг серверээс шалгана. `config.js` дахь publishable key олон нийтэд харагддаг байх нь хэвийн; service-role/secret key-ийг түүнд ХЭЗЭЭ Ч бүү хий.
