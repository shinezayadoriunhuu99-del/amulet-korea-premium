// Энэ файл дахь Supabase ANON/PUBLISHABLE KEY бол нийтэд харагдаж болох түлхүүр.
// SERVICE_ROLE / SECRET KEY-ийг ЭНД ХЭЗЭЭ Ч БҮҮ ХИЙ!
window.AMULET_CONFIG = {
  supabaseUrl: '',
  supabaseAnonKey: '',
  currency: 'KRW',
  contactEmail: 'hello@example.com',
  socialUrl: ''
};
