// Vercel serverless endpoint: validates product prices and stock server-side.
const json=(res,status,body)=>{res.statusCode=status;res.setHeader('Content-Type','application/json; charset=utf-8');res.setHeader('Cache-Control','no-store');res.end(JSON.stringify(body))};
const validText=(v,min,max)=>typeof v==='string'&&v.trim().length>=min&&v.trim().length<=max;
module.exports=async function handler(req,res){
 if(req.method!=='POST'){res.setHeader('Allow','POST');return json(res,405,{error:'POST хүсэлт шаардлагатай'})}
 const url=(process.env.SUPABASE_URL||'').replace(/\/$/,'');const key=process.env.SUPABASE_SERVICE_ROLE_KEY||'';
 if(!url||!key)return json(res,503,{error:'Захиалгын сервер тохируулаагүй байна'});
 const body=typeof req.body==='string'?(()=>{try{return JSON.parse(req.body)}catch{return null}})():req.body;
 if(!body||!validText(body.customer_name,2,100)||!validText(body.phone,6,30)||!validText(body.address,8,500)||!Array.isArray(body.items)||body.items.length<1||body.items.length>30||(![undefined,null].includes(body.note)&&!validText(body.note,0,500)))return json(res,400,{error:'Захиалгын мэдээлэл дутуу эсвэл буруу байна'});
 if(body.items.some(i=>!i||typeof i.product_id!=='string'||!/^[0-9a-f-]{36}$/i.test(i.product_id)||!Number.isInteger(i.quantity)||i.quantity<1||i.quantity>100))return json(res,400,{error:'Барааны мэдээлэл буруу байна'});
 const quantities=new Map();for(const item of body.items)quantities.set(item.product_id,(quantities.get(item.product_id)||0)+item.quantity);
 if([...quantities.values()].some(q=>q>100))return json(res,400,{error:'Барааны тоо хэт их байна'});
 const headers={apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json'};
 try{
  const ids=[...quantities.keys()];const where=`(${ids.map(id=>`"${id}"`).join(',')})`;
  const r=await fetch(`${url}/rest/v1/products?select=id,name,price,stock,active&id=in.${encodeURIComponent(where)}`,{headers});if(!r.ok)throw Error('product read failed');const rows=await r.json();
  if(!Array.isArray(rows)||rows.length!==ids.length)return json(res,409,{error:'Нэг буюу хэд хэдэн бараа олдсонгүй'});
  let total=0;const items=[];for(const p of rows){const qty=quantities.get(p.id);if(!p.active||!Number.isInteger(p.price)||p.price<=0||p.stock<qty)return json(res,409,{error:`${p.name} барааны үлдэгдэл хүрэлцэхгүй`});total+=p.price*qty;items.push({product_id:p.id,name:p.name,unit_price:p.price,quantity:qty})}
  if(!Number.isSafeInteger(total)||total>1000000000)return json(res,400,{error:'Дүн хэт их байна'});
  // Stock is checked before writing; for high-volume shops implement transactional stock reservation RPC.
  const order={customer_name:body.customer_name.trim(),phone:body.phone.trim(),address:body.address.trim(),note:(body.note||'').trim(),items,total_amount:total,status:'new'};
  const saved=await fetch(`${url}/rest/v1/orders?select=id`,{method:'POST',headers:{...headers,Prefer:'return=representation'},body:JSON.stringify(order)});if(!saved.ok)throw Error('order save failed');const data=await saved.json();return json(res,201,{ok:true,order_id:data?.[0]?.id,total_amount:total});
 }catch(e){return json(res,500,{error:'Захиалга хадгалах үед алдаа гарлаа. Дахин оролдоно уу.'})}
};
