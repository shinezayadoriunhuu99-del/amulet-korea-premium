-- AMULET KOREA: Run once in a NEW Supabase project (SQL Editor).
-- Prices stored as integer KRW. Only admin users can update products and read orders.
create extension if not exists pgcrypto;
create table if not exists public.admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.products (
 id uuid primary key default gen_random_uuid(),
 name text not null check(length(name) between 1 and 150),
 category text not null default 'Бусад',
 description text not null default '',
 price integer not null check(price>0),
 stock integer not null default 0 check(stock>=0),
 badge text not null default '',
 emoji text not null default '✦',
 color text not null default '#e9eae5',
 image_url text,
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(),
 customer_name text not null,
 phone text not null,
 address text not null,
 note text not null default '',
 items jsonb not null,
 total_amount integer not null check(total_amount>0),
 status text not null default 'new' check(status in ('new','confirmed','shipping','completed','cancelled')),
 created_at timestamptz not null default now()
);
create index if not exists products_active_created_idx on public.products(active,created_at desc);
create index if not exists orders_created_idx on public.orders(created_at desc);
alter table public.admin_users enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
create or replace function public.is_amulet_admin() returns boolean
language sql stable security definer set search_path = '' as $$
 select exists (select 1 from public.admin_users where user_id = (select auth.uid()));
$$;
revoke all on function public.is_amulet_admin() from public;
grant execute on function public.is_amulet_admin() to authenticated, anon;
-- Restrict admin_users direct access (service role manages membership).
revoke all on public.admin_users from anon, authenticated;
grant select on public.products to anon, authenticated;
grant insert, update, delete on public.products to authenticated;
grant select, update on public.orders to authenticated;
-- No INSERT grant for anon/authenticated: only the service-role backend can accept orders.
drop policy if exists "Public active products" on public.products;
create policy "Public active products" on public.products for select to anon,authenticated using (active = true or (select public.is_amulet_admin()));
drop policy if exists "Admins create products" on public.products;
create policy "Admins create products" on public.products for insert to authenticated with check ((select public.is_amulet_admin()));
drop policy if exists "Admins edit products" on public.products;
create policy "Admins edit products" on public.products for update to authenticated using ((select public.is_amulet_admin())) with check ((select public.is_amulet_admin()));
drop policy if exists "Admins delete products" on public.products;
create policy "Admins delete products" on public.products for delete to authenticated using ((select public.is_amulet_admin()));
drop policy if exists "Admins read orders" on public.orders;
create policy "Admins read orders" on public.orders for select to authenticated using ((select public.is_amulet_admin()));
drop policy if exists "Admins update orders" on public.orders;
create policy "Admins update orders" on public.orders for update to authenticated using ((select public.is_amulet_admin())) with check ((select public.is_amulet_admin()));
-- IMPORTANT: After creating your OWN Supabase Auth admin user in the dashboard, run:
-- insert into public.admin_users(user_id) values ('YOUR-AUTH-USER-UUID');
-- Don't paste passwords or service-role keys into GitHub.
